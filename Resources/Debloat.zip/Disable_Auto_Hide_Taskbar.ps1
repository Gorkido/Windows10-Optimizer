#Change these three to match up to the extracted registry data and run as Admin
$YourInput = "30,00,00,00,fe,ff,ff,ff,02,00,00,00,03,00,00,00,5d,00,00,00,3c,\
  00,00,00,00,00,00,00,fc,03,00,00,80,07,00,00,38,04,00,00,90,00,00,00,01,00,\
  00,00"
$RegPath   = 'HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\StuckRects3\Settings'
$AttrName  = "FailureActions"

$hexified = $YourInput.Split(',') | % { "0x$_"}
New-ItemProperty -Path $RegPath -Name $AttrName -PropertyType Binary -Value ([byte[]]$hexified)