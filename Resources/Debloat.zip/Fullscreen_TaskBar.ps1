$ErrorActionPreference = 'SilentlyContinue'

        Write-Host "Enabling Fullscreen Taskbar"
        $Start = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer"
        Set-ItemProperty $Start ForceStartSize -Value 2
        Start-Sleep 1
        Write-Host "Fullscreen Taskbar Enabled"

        Write-Host "Stopping explorer"
        Start-Sleep 1
        taskkill.exe /F /IM explorer.exe
        Start-Sleep 1
        Write-Host "Starting explorer"
        Start-Sleep 1
        Start-Process explorer.exe -NoNewWindow