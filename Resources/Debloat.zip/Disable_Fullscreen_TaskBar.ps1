$ErrorActionPreference = 'SilentlyContinue'

        Write-Host "Disabling Fullscreen Taskbar"
        $Start = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer"
        Set-ItemProperty $Start ForceStartSize -Value 0
        Start-Sleep 1
        Write-Host "Fullscreen Taskbar Disabled"

        Write-Host "Stopping explorer"
        Start-Sleep 1
        taskkill.exe /F /IM explorer.exe
        Start-Sleep 1
        Write-Host "Starting explorer"
        Start-Sleep 1
        Start-Process explorer.exe -NoNewWindow