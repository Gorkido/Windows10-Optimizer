$ErrorActionPreference = 'SilentlyContinue'

        Write-Host "Enabling Dark Mode"
        $Theme = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize"
        Set-ItemProperty $Theme AppsUseLightTheme -Value 1
        Start-Sleep 1
        Write-Host "Enabled"

                Write-Host "Stopping explorer"
        Start-Sleep 1
        taskkill.exe /F /IM explorer.exe
        Start-Sleep 1
        Write-Host "Starting explorer"
        Start-Sleep 1
        Start-Process explorer.exe -NoNewWindow