    #Use Small Taskbar Icons    
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "TaskbarSmallIcons" -Type DWord -Value 1
    Stop-Process -Name "explorer" -ErrorAction SilentlyContinue
    write-Host "You should have small taskbar icons now!"